-- 20 useful SQL queries for College Management Project (works in SQLite / PostgreSQL with minor tweaks)

-- 1. List all students with their department
SELECT s.student_id, s.first_name || ' ' || s.last_name AS student_name, d.name AS department
FROM Students s
LEFT JOIN Departments d ON s.dept_id = d.dept_id;

-- 2. Students enrolled in CS101
SELECT s.student_id, s.first_name, s.last_name
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
JOIN Courses c ON e.course_id = c.course_id
WHERE c.course_code = 'CS101';

-- 3. Course-wise enrollment counts
SELECT c.course_code, c.title, COUNT(e.enrollment_id) AS enrolled_students
FROM Courses c
LEFT JOIN Enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id;

-- 4. Professor teaching load (number of courses)
SELECT p.prof_id, p.first_name || ' ' || p.last_name AS professor, COUNT(c.course_id) AS courses_taught
FROM Professors p
LEFT JOIN Courses c ON p.prof_id = c.professor_id
GROUP BY p.prof_id;

-- 5. Students with GPA-like average (from Results)
-- Note: assumes grade mapping; here we'll calculate average marks
SELECT r.student_id, s.first_name || ' ' || s.last_name AS student, AVG(r.marks_obtained) AS avg_marks
FROM Results r
JOIN Students s ON r.student_id = s.student_id
GROUP BY r.student_id
ORDER BY avg_marks DESC;

-- 6. Upcoming exams (next 30 days)
SELECT e.exam_id, c.course_code, c.title, e.exam_date
FROM Exams e
JOIN Courses c ON e.course_id = c.course_id
WHERE DATE(e.exam_date) BETWEEN DATE('now') AND DATE('now','+30 days')
ORDER BY e.exam_date;

-- 7. Attendance percentage for a student in a course
SELECT s.student_id, s.first_name || ' ' || s.last_name AS student,
  SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END)*100.0/COUNT(a.attendance_id) AS attendance_pct
FROM Attendance a
JOIN Students s ON a.student_id = s.student_id
WHERE a.course_id = 201 AND s.student_id = 1001
GROUP BY s.student_id;

-- 8. Students who have not completed any course (no grade assigned)
SELECT s.student_id, s.first_name || ' ' || s.last_name AS student
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
WHERE e.grade IS NULL;

-- 9. Department-wise average marks
SELECT d.name AS department, AVG(r.marks_obtained) AS avg_marks
FROM Results r
JOIN Students s ON r.student_id = s.student_id
JOIN Departments d ON s.dept_id = d.dept_id
GROUP BY d.dept_id;

-- 10. Top performers (avg marks > 85)
SELECT r.student_id, s.first_name || ' ' || s.last_name AS student, AVG(r.marks_obtained) AS avg_marks
FROM Results r
JOIN Students s ON r.student_id = s.student_id
GROUP BY r.student_id
HAVING AVG(r.marks_obtained) > 85;

-- 11. Courses scheduled in Block A
SELECT c.course_code, c.title, t.day_of_week, t.start_time, t.end_time, cl.building, cl.room_number
FROM Courses c
JOIN Timetable t ON c.course_id = t.course_id
JOIN Classrooms cl ON t.room_id = cl.room_id
WHERE cl.building = 'Block A';

-- 12. Students per year (year-wise count)
SELECT year, COUNT(*) AS students_count
FROM Students
GROUP BY year
ORDER BY year;

-- 13. Find students who failed (marks < 40) in any exam
SELECT DISTINCT s.student_id, s.first_name || ' ' || s.last_name AS student
FROM Results r
JOIN Students s ON r.student_id = s.student_id
WHERE r.marks_obtained < 40;

-- 14. Average class size per course (based on enrollments)
SELECT c.course_code, c.title, COUNT(e.enrollment_id) AS class_size
FROM Courses c
LEFT JOIN Enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id
ORDER BY class_size DESC;

-- 15. Professors with highest average student marks (across their courses' exams)
SELECT p.prof_id, p.first_name || ' ' || p.last_name AS professor, AVG(r.marks_obtained) AS avg_marks
FROM Professors p
JOIN Courses c ON p.prof_id = c.professor_id
JOIN Exams ex ON c.course_id = ex.course_id
JOIN Results r ON ex.exam_id = r.exam_id
GROUP BY p.prof_id
ORDER BY avg_marks DESC;

-- 16. Students who are enrolled in courses from multiple departments
SELECT s.student_id, s.first_name || ' ' || s.last_name AS student, COUNT(DISTINCT c.dept_id) AS dept_count
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
JOIN Courses c ON e.course_id = c.course_id
GROUP BY s.student_id
HAVING dept_count > 1;

-- 17. Recent enrollments (last 90 days)
SELECT e.enrollment_id, s.first_name || ' ' || s.last_name AS student, c.course_code, e.enroll_date
FROM Enrollments e
JOIN Students s ON e.student_id = s.student_id
JOIN Courses c ON e.course_id = c.course_id
WHERE DATE(e.enroll_date) BETWEEN DATE('now','-90 days') AND DATE('now');

-- 18. Students with perfect attendance in a given period (example simple query)
-- This is a simplified approach: count presents equals total class days in that period (requires class days table for accuracy)
SELECT a.student_id, s.first_name || ' ' || s.last_name AS student, SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) AS presents
FROM Attendance a
JOIN Students s ON a.student_id = s.student_id
WHERE a.date BETWEEN DATE('2023-11-01') AND DATE('2023-11-30')
GROUP BY a.student_id
HAVING presents = (SELECT COUNT(DISTINCT date) FROM Attendance WHERE date BETWEEN DATE('2023-11-01') AND DATE('2023-11-30'));

-- 19. Add a new column: example ALTER TABLE to add email_verified
ALTER TABLE Students ADD COLUMN email_verified INTEGER DEFAULT 0;

-- 20. Use a CTE to find students and their total credits (assumes all enrolled courses' credits sum)
WITH student_credits AS (
  SELECT e.student_id, SUM(c.credits) AS total_credits
  FROM Enrollments e
  JOIN Courses c ON e.course_id = c.course_id
  GROUP BY e.student_id
)
SELECT sc.student_id, s.first_name || ' ' || s.last_name AS student, sc.total_credits
FROM student_credits sc
JOIN Students s ON sc.student_id = s.student_id
ORDER BY sc.total_credits DESC;
