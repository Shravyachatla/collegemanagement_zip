-- Sample data for College Management Project (SQLite compatible)
BEGIN TRANSACTION;

-- Departments
INSERT INTO Departments(dept_id, name, building, head_professor_id) VALUES
(1, 'Computer Science', 'Block A', NULL),
(2, 'Electronics', 'Block B', NULL),
(3, 'Mathematics', 'Block C', NULL);

-- Professors
INSERT INTO Professors(prof_id, first_name, last_name, email, dept_id, hire_date, salary) VALUES
(1, 'Asha', 'Reddy', 'asha.reddy@college.edu', 1, '2015-07-01', 85000),
(2, 'Vikram', 'Shah', 'vikram.shah@college.edu', 2, '2012-09-15', 90000),
(3, 'Neha', 'Iyer', 'neha.iyer@college.edu', 3, '2018-01-20', 75000),
(4, 'Rohit', 'Kumar', 'rohit.kumar@college.edu', 1, '2020-06-10', 70000);

-- Update head_professor_id
UPDATE Departments SET head_professor_id = 1 WHERE dept_id = 1;
UPDATE Departments SET head_professor_id = 2 WHERE dept_id = 2;
UPDATE Departments SET head_professor_id = 3 WHERE dept_id = 3;

-- Students
INSERT INTO Students(student_id, first_name, last_name, email, dob, enrollment_date, dept_id, year, gender) VALUES
(1001, 'Priya', 'Nair', 'priya.nair@student.edu', '2002-05-10', '2020-08-01', 1, 3, 'F'),
(1002, 'Arjun', 'Patel', 'arjun.patel@student.edu', '2001-11-30', '2019-08-01', 1, 4, 'M'),
(1003, 'Sana', 'Khan', 'sana.khan@student.edu', '2003-02-14', '2021-08-01', 2, 2, 'F'),
(1004, 'Manish', 'Gupta', 'manish.gupta@student.edu', '2000-07-22', '2018-08-01', 3, 4, 'M'),
(1005, 'Riya', 'Sharma', 'riya.sharma@student.edu', '2002-10-01', '2020-08-01', 1, 3, 'F'),
(1006, 'Kabir', 'Singh', 'kabir.singh@student.edu', '2003-03-05', '2021-08-01', 2, 2, 'M'),
(1007, 'Meera', 'Desai', 'meera.desai@student.edu', '2004-01-17', '2022-08-01', 1, 1, 'F'),
(1008, 'Amit', 'Verma', 'amit.verma@student.edu', '2001-12-12', '2019-08-01', 3, 4, 'M'),
(1009, 'Neel', 'Bose', 'neel.bose@student.edu', '2002-04-02', '2020-08-01', 2, 3, 'M'),
(1010, 'Lina', 'Roy', 'lina.roy@student.edu', '2003-09-09', '2021-08-01', 3, 2, 'F');

-- Courses
INSERT INTO Courses(course_id, course_code, title, credits, dept_id, professor_id, semester) VALUES
(201, 'CS101', 'Intro to Programming', 4, 1, 1, 'Fall'),
(202, 'CS201', 'Data Structures', 4, 1, 4, 'Spring'),
(203, 'EC101', 'Circuits 101', 3, 2, 2, 'Fall'),
(204, 'MA101', 'Calculus I', 4, 3, 3, 'Fall'),
(205, 'CS301', 'Database Systems', 3, 1, 1, 'Fall');

-- Classrooms
INSERT INTO Classrooms(room_id, building, room_number, capacity) VALUES
(1, 'Block A', 'A101', 60),
(2, 'Block B', 'B201', 40),
(3, 'Block C', 'C105', 50);

-- Timetable
INSERT INTO Timetable(tt_id, course_id, room_id, day_of_week, start_time, end_time) VALUES
(1,201,1,'Monday','09:00','11:00'),
(2,202,1,'Wednesday','11:00','13:00'),
(3,203,2,'Tuesday','10:00','12:00'),
(4,204,3,'Monday','14:00','16:00'),
(5,205,1,'Friday','09:00','11:00');

-- Enrollments
INSERT INTO Enrollments(enrollment_id, student_id, course_id, enroll_date, status, grade) VALUES
(1,1001,201,'2020-08-10','enrolled',NULL),
(2,1002,201,'2019-08-05','enrolled','A'),
(3,1005,201,'2020-08-12','enrolled',NULL),
(4,1003,203,'2021-08-11','enrolled',NULL),
(5,1006,203,'2021-08-12','enrolled','B'),
(6,1004,204,'2018-08-10','enrolled','A'),
(7,1008,204,'2019-08-09','enrolled','B'),
(8,1001,205,'2021-01-15','completed','A'),
(9,1009,203,'2020-08-15','enrolled',NULL),
(10,1010,204,'2021-08-18','enrolled',NULL);

-- Exams
INSERT INTO Exams(exam_id, course_id, exam_date, max_marks) VALUES
(301,201,'2023-12-10',100),
(302,203,'2023-12-12',100),
(303,204,'2023-12-15',100);

-- Results
INSERT INTO Results(result_id, exam_id, student_id, marks_obtained, grade) VALUES
(401,301,1001,78,'B'),
(402,301,1002,92,'A'),
(403,302,1003,65,'C'),
(404,303,1004,88,'B');

-- Attendance (sample entries)
INSERT INTO Attendance(attendance_id, student_id, course_id, date, status) VALUES
(501,1001,201,'2023-11-01','present'),
(502,1002,201,'2023-11-01','present'),
(503,1005,201,'2023-11-01','absent'),
(504,1003,203,'2023-11-02','present'),
(505,1006,203,'2023-11-02','late');

COMMIT;
