# College Management SQL Project

Contents:
- `schema.sql`        : Database schema (CREATE TABLE statements)
- `sample_data.sql`   : INSERT statements with sample rows
- `queries.sql`       : 20 useful queries (joins, aggregates, window/CTE examples)
- `ER_diagram.svg`    : Simple ER diagram (SVG)
- `README.md`         : This file

How to use:
1. For SQLite:
   - Initialize a database and run `schema.sql`, then `sample_data.sql`.
     Example:
       ```
       sqlite3 college.db < schema.sql
       sqlite3 college.db < sample_data.sql
       ```
2. For PostgreSQL / MySQL:
   - You may need to adapt `PRAGMA` statements and `DATE('now')` functions.
   - Use appropriate data types and auto-increment syntax.

Notes:
- The sample data is small by design; extend `sample_data.sql` for larger tests.
- Queries use `DATE('now')` which works in SQLite. Replace with `CURRENT_DATE` for PostgreSQL.
- The project includes an SVG ER diagram which can be opened in any modern browser.

Enjoy — modify and extend as needed!
