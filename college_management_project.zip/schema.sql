-- College Management Schema
PRAGMA foreign_keys = ON;

CREATE TABLE Departments (
    dept_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    building TEXT,
    head_professor_id INTEGER
);

CREATE TABLE Professors (
    prof_id INTEGER PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE,
    dept_id INTEGER,
    hire_date DATE,
    salary REAL,
    FOREIGN KEY(dept_id) REFERENCES Departments(dept_id)
);

CREATE TABLE Students (
    student_id INTEGER PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE,
    dob DATE,
    enrollment_date DATE,
    dept_id INTEGER,
    year INTEGER,
    gender TEXT,
    FOREIGN KEY(dept_id) REFERENCES Departments(dept_id)
);

CREATE TABLE Courses (
    course_id INTEGER PRIMARY KEY,
    course_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    credits INTEGER NOT NULL,
    dept_id INTEGER,
    professor_id INTEGER,
    semester TEXT,
    FOREIGN KEY(dept_id) REFERENCES Departments(dept_id),
    FOREIGN KEY(professor_id) REFERENCES Professors(prof_id)
);

CREATE TABLE Classrooms (
    room_id INTEGER PRIMARY KEY,
    building TEXT,
    room_number TEXT,
    capacity INTEGER
);

CREATE TABLE Timetable (
    tt_id INTEGER PRIMARY KEY,
    course_id INTEGER,
    room_id INTEGER,
    day_of_week TEXT,
    start_time TEXT,
    end_time TEXT,
    FOREIGN KEY(course_id) REFERENCES Courses(course_id),
    FOREIGN KEY(room_id) REFERENCES Classrooms(room_id)
);

CREATE TABLE Enrollments (
    enrollment_id INTEGER PRIMARY KEY,
    student_id INTEGER,
    course_id INTEGER,
    enroll_date DATE,
    status TEXT DEFAULT 'enrolled',
    grade TEXT,
    FOREIGN KEY(student_id) REFERENCES Students(student_id),
    FOREIGN KEY(course_id) REFERENCES Courses(course_id)
);

CREATE TABLE Exams (
    exam_id INTEGER PRIMARY KEY,
    course_id INTEGER,
    exam_date DATE,
    max_marks INTEGER,
    FOREIGN KEY(course_id) REFERENCES Courses(course_id)
);

CREATE TABLE Results (
    result_id INTEGER PRIMARY KEY,
    exam_id INTEGER,
    student_id INTEGER,
    marks_obtained INTEGER,
    grade TEXT,
    FOREIGN KEY(exam_id) REFERENCES Exams(exam_id),
    FOREIGN KEY(student_id) REFERENCES Students(student_id)
);

CREATE TABLE Attendance (
    attendance_id INTEGER PRIMARY KEY,
    student_id INTEGER,
    course_id INTEGER,
    date DATE,
    status TEXT CHECK(status IN ('present','absent','late')),
    FOREIGN KEY(student_id) REFERENCES Students(student_id),
    FOREIGN KEY(course_id) REFERENCES Courses(course_id)
);

-- Indexes for performance
CREATE INDEX idx_students_dept ON Students(dept_id);
CREATE INDEX idx_courses_dept ON Courses(dept_id);
CREATE INDEX idx_enrollments_student ON Enrollments(student_id);
